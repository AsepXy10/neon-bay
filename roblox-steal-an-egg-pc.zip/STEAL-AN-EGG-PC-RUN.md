# Steal An Egg — render di PC (VM mentok di browser)

Story sudah jadi + lolos lint di VM. Yang mentok: render butuh headless Chrome
dengan WebGL; di VM tidak ada GPU dan Chromium yang tersedia memblokir akses
local-network (render.mjs butuh HTTP server lokal) — lihat "Kenapa VM mentok".
Jalankan render ini di PC user (Windows + Chrome + GPU), sesuai setup repo.

## Yang sudah beres di VM (tinggal git push / copy folder ini ke PC)
- Repo: `celoalze/roblox-in-this-town-threejs` (clone di `~/workspace/roblox-in-this-town-threejs/`)
- Story: `stories/steal-an-egg/story.json` — 11 scenes, ~30 detik, genre `aaa_story`
  (narasi Inggris, caption Inggris di video, caption TikTok Indonesia).
  Lint: OK. Durasi estimasi 30 detik.
- Prop baru: `egg` (telur bercahaya) + `nest` (sarang) — ditambah di
  `engine/props/props.js` + `config/vocab.json` (sudah terdaftar di `--vocab prop`).
  Cerita: telur menetas jadi BAYI T-Rex (bukan gorila — repo tidak punya model
  gorila; bayi T-Rex lebih nyambung: telur dijaga T-Rex).
- Deps terinstall di VM (npm + venv + model Kokoro) — di PC install ulang
  via setup.bat (lihat bawah). Narasi pakai Kokoro offline GRATIS (suara
  `am_michael`); JANGAN set ELEVENLABS_API_KEY (berbayar).

## Cara render di PC (Windows, PowerShell/CMD, di folder repo)
```bat
setup.bat
python pipeline/produce.py steal-an-egg --lint
python pipeline/produce.py steal-an-egg --preview
python pipeline/produce.py steal-an-egg
```
Hasil: `publish\steal-an-egg\` (mp4 + _nomusic.mp4 + youtube.txt + tiktok.txt).
Syarat PC: Python 3.10+, Node 18+, ffmpeg, Google Chrome, driver GPU terbaru.
Catatan: render SELALU pakai GPU (repo). Kalau preview ada frame gelap/kosong,
jalankan `--qa` dulu sebelum render penuh.

## Kenapa VM mentok (untuk yang mau coba lagi)
- GPU: tidak ada (no nvidia-smi, no /dev/dri). Render.mjs punya fallback
  software (`RS_CPU=1` → SwiftShader) — fallback-nya ada, tapi tidak pernah
  sampai ke sana karena Chrome-nya yang gagal.
- Chrome: download Chromium diblokir policy VM. Chromium yang tersedia:
  `/opt/meta-chromium/chrome` ("Muse Browser 157") BISA jalan headless via
  puppeteer-core + flag policy WebGL
  (`--hatch-webgl-allowed-domains-file=.../webgl-allowed-domains.txt`
  `--hatch-webgl-allowed-domains-sha256=8097045f...`), TAPI build ini
  memblokir navigasi ke alamat local-network
  (`ERR_BLOCKED_BY_LOCAL_NETWORK_ACCESS_CHECKS` untuk 127.0.0.1/localhost;
  tidak mempan `--disable-web-security` / `--disable-features=
  LocalNetworkAccess,BlockInsecurePrivateNetworkRequests,
  PrivateNetworkAccessSendPreflights`), padahal render.mjs menyajikan
  `engine/page.html` lewat HTTP server di 127.0.0.1. Engine juga memakai
  banyak path absolut (`/assets/...`, `/config/...`) sehingga jalan `file://`
  butuh fork engine — tidak dilakukan.
- `hatch-chromium-sandbox` (bwrap + SOCKS proxy bridge) juga dicoba: browser
  jalan tapi tanpa network dari shell (ERR_INTERNET_DISCONNECTED, bahkan ke
  example.com) karena proxy socket runtime tidak tersedia di shell.
- TTS Kokoro offline SUDAH terbukti jalan di VM (1 baris → wav 4,3 detik).
  Jadi yang kurang hanya frame render-nya.

## Kalau render PC juga mentok
Cadangan (dari research skill 28 Nov 2026, `~/workspace/roblox-skill-search/`):
- RoShot Studio — video pertama GRATIS, visual Roblox 100% asli.
- playlikemen/roblox-reels-skill — gratis, render CPU (tanpa GPU).
